﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace student_test_tizimi
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Jamol\Desktop\student_test_tizimi\student_test_tizimi\student_test_tizimi\QuiseMenegementDatabase.mdf;Integrated Security=True");

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            Con.Open();
            string query1 = "SELECT distinct sett FROM tblQuestion";
            SqlDataAdapter sda = new SqlDataAdapter(query1, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds1 = new DataSet();
            sda.Fill(ds1);
            Con.Close();
            DataTable dt = ds1.Tables[0];
            txtQuestion.Text= ds1.Tables[0].Rows[0][0].ToString();
            //for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
            //{
            //    txtQuestion.Text= ds1.Tables[0].Rows[i][0].ToString();
            //}

            if (comboBox1.SelectedIndex != -1)
            {
                panel1.Visible = false;
            }
            else
            {
                MessageBox.Show("Select set.");
            }
        }

        private void txtQuestion_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
