﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_test_tizimi
{
    public partial class UC_UpdateQuestion : Form
    {
        public UC_UpdateQuestion()
        {
            InitializeComponent();
        }

        private void Display()
        {
            Con.Open();
            string query = "SELECT * FROM tblQuestion";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            Con.Close();
        }

        private void clear()
        {
            txtAnswer.Text = "";
            txtOption1.Text = "";
            txtOption2.Text = "";
            txtOption3.Text = "";
            txtOption4.Text = "";
            txtQuestion.Text = "";
        }

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Jamol\Desktop\student_test_tizimi\student_test_tizimi\student_test_tizimi\QuiseMenegementDatabase.mdf;Integrated Security=True");

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (comboQuestion.SelectedIndex != -1)
            {
                Con.Open();
                string query = "UPDATE tblQuestion SET sett='" + comboSet.SelectedItem.ToString() + "', questin='" + txtQuestion.Text + "', option1='" + txtOption1.Text + "', option2='" + txtOption2.Text + "', option3='" + txtOption3.Text + "', option4='" + txtOption4.Text + "', answerr='" + txtAnswer.Text + "' where nomer='" + comboQuestion.SelectedItem.ToString() + "' and sett = '"+comboSet.SelectedItem.ToString()+"'";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Ma'lumot tahrirlandi", "Update");
                Con.Close();
                Display();
                clear();

            }
            else
            {
                MessageBox.Show("Select Question First.", "Message!!!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }


        private void UC_UpdateQuestion_Load(object sender, EventArgs e)
        {
            comboSet.Items.Clear();
            Con.Open();
            string query = "SELECT * FROM tblQuestion";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds1 = new DataSet();
            sda.Fill(ds1);
            Con.Close();
            DataTable dt = ds1.Tables[0];
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboSet.Items.Add(dt.Rows[i]["sett"].ToString());
            }
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                comboQuestion.Items.Add(dt.Rows[i]["nomer"].ToString());
            }

        }

        private void comboSet_SelectedIndexChanged(object sender, EventArgs e)
        {
            /* Con.Open();
            string query = "SELECT nomer FROM tblQuestion where sett='"+comboSet+"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds1 = new DataSet();
            sda.Fill(ds1);
            Con.Close();
            DataTable dt = ds1.Tables[0];*/
        }

        private void comboQuestion_SelectedIndexChanged(object sender, EventArgs e)
        {
            Con.Open();
            string query = "SELECT questin,option1,option2,option3,option4,answerr FROM tblQuestion where sett='" + comboSet.Text + "'and nomer ='" + comboQuestion.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds1 = new DataSet();
            sda.Fill(ds1);
            Con.Close();
            DataTable dt = ds1.Tables[0];
            if (ds1.Tables[0].Rows.Count > 0)
            {
                txtQuestion.Text = ds1.Tables[0].Rows[0][0].ToString();
                txtOption1.Text = ds1.Tables[0].Rows[0][1].ToString();
                txtOption2.Text = ds1.Tables[0].Rows[0][2].ToString();
                txtOption3.Text = ds1.Tables[0].Rows[0][3].ToString();
                txtOption4.Text = ds1.Tables[0].Rows[0][4].ToString();
                txtAnswer.Text = ds1.Tables[0].Rows[0][5].ToString();
            }
            
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        public void ClearAll()
        {
            txtAnswer.Clear();
            txtOption1.Clear();
            txtOption2.Clear();
            txtOption3.Clear();
            txtOption4.Clear();
            txtQuestion.Clear();
            comboSet.SelectedIndex = comboQuestion.SelectedIndex = -1;
            
        }

        private void btnSync_Click(object sender, EventArgs e)
        {
            UC_UpdateQuestion_Load(this, null);
        }
    }
}
