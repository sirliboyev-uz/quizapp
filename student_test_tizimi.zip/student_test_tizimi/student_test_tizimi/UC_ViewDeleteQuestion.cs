﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_test_tizimi
{
    public partial class UC_ViewDeleteQuestion : Form
    {
        public UC_ViewDeleteQuestion()
        {
            InitializeComponent();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Jamol\Desktop\student_test_tizimi\student_test_tizimi\student_test_tizimi\QuiseMenegementDatabase.mdf;Integrated Security=True");
        private void UC_ViewDeleteQuestion_Load(object sender, EventArgs e)
        {
            comboSet.Items.Clear();
            comboSet.Items.Add("All Question");
            Con.Open();
            string query1 = "SELECT distinct sett FROM tblQuestion";
            SqlDataAdapter sda = new SqlDataAdapter(query1, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds1 = new DataSet();
            sda.Fill(ds1);
            Con.Close();
            DataTable dt = ds1.Tables[0];
            for (int i = 0; i < ds1.Tables[0].Rows.Count; i++)
            {
                comboSet.Items.Add(ds1.Tables[0].Rows[i][0].ToString());
            }
            
        }

        private void comboSet_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboSet.SelectedIndex != 0)
            {
                Con.Open();
                string query = "SELECT * FROM tblQuestion WHERE sett = @sett";
                SqlCommand command = new SqlCommand(query, Con);
                command.Parameters.AddWithValue("@sett", comboSet.SelectedItem.ToString());
                SqlDataAdapter sda = new SqlDataAdapter(command);
                SqlCommandBuilder build = new SqlCommandBuilder(sda);
                var ds1 = new DataSet();
                sda.Fill(ds1);
                dataGridView1.DataSource = ds1.Tables[0];
                Con.Close();
            }
            else
            {
                Con.Open();
                string query = "SELECT * FROM tblQuestion";
                SqlCommand command = new SqlCommand(query, Con);
                command.Parameters.AddWithValue("@sett", comboSet.SelectedItem.ToString());
                SqlDataAdapter sda = new SqlDataAdapter(command);
                SqlCommandBuilder build = new SqlCommandBuilder(sda);
                var ds1 = new DataSet();
                sda.Fill(ds1);
                dataGridView1.DataSource = ds1.Tables[0];
                Con.Close();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            

            
            if(MessageBox.Show("Are you Sure?","Delete Confirmation !", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                Con.Open();
                string query = "DELETE FROM tblQuestion WHERE id = "+id+" and nomer='"+questionNo+"'";
                SqlCommand command = new SqlCommand(query, Con);
                command.Parameters.AddWithValue("@id", dataGridView1.SelectedRows[0].Cells["id"].Value);
                int affectedRows = command.ExecuteNonQuery();
                var ds1 = new DataSet();
                UC_ViewDeleteQuestion_Load(this, null);
                
                Con.Close();
                if (affectedRows > 0)
                {
                    MessageBox.Show("Ma'lumot o'chirildi!");
                    // DataGridViewdan o'chirilgan qatorni olib tashlash
                    dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
                }
                else
                {
                    MessageBox.Show("Ma'lumot o'chirishda xatolik yuz berdi!");
                }
            }

        }
        int id, questionNo;

        private void btnSync_Click(object sender, EventArgs e)
        {
            UC_ViewDeleteQuestion_Load(this, null);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                id = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                questionNo = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString());
            }
            catch { }
        }
    }
}
