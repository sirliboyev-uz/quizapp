﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace student_test_tizimi
{
    public partial class UC_AddNewQuestion : Form
    {
        public UC_AddNewQuestion()
        {
            InitializeComponent();
            Display();
        }

        private void Display()
        {
            Con.Open();
            string query = "SELECT * FROM tblQuestion";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            Con.Close();
        }

        private void clear()
        {
            txtAnswer.Text = "";
            txtOption1.Text = "";
            txtOption2.Text = "";
            txtOption3.Text = "";
            txtOption4.Text = "";
            txtQuestion.Text = "";
        }

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Jamol\Desktop\student_test_tizimi\student_test_tizimi\student_test_tizimi\QuiseMenegementDatabase.mdf;Integrated Security=True");
        int i = 1;
        private void btnNext_Click(object sender, EventArgs e)
        {

            if (txtSet.Text == "" || txtQuestion.Text == "" || txtOption4.Text == "" || txtOption3.Text == "" || txtOption2.Text == "" || txtOption1.Text == "" || txtAnswer.Text == "")
            {
                MessageBox.Show("Missing Information!");
            }
            else
            {
                Con.Open();
                SqlCommand sqlcmd = new SqlCommand("INSERT INTO tblQuestion (sett,nomer,questin,option1,option2,option3,option4,answerr) " +
                    "VALUES('" + txtSet.Text + "','" + txtQuestionNo.Text + "','" + txtQuestion.Text + "','" + txtOption1.Text + "','" + txtOption2.Text + "','" + txtOption3.Text + "','" + txtOption4.Text + "','" + txtAnswer.Text + "')", Con);
                sqlcmd.ExecuteNonQuery();
                MessageBox.Show("New User Added Successfly", "INSERT");
                Con.Close();
                Display();
                clear();
                txtQuestionNo.Text = Convert.ToString(i++);                               
            }
        }
        Int64 questionNo = 1;
        private void UC_AddNewQuestion_Load(object sender, EventArgs e)
        {
            Con.Open();
            string query = "SELECT max(sett) FROM tblQuestion";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds1 = new DataSet();
            sda.Fill(ds1);
            Con.Close();
            if(ds1.Tables[0].Rows.Count!=0 && ds1.Tables[0].Rows[0][0].ToString() != "")
            {
                Int64 id = Int64.Parse(ds1.Tables[0].Rows[0][0].ToString());
                txtSet.Text = (id + 1).ToString();
            }
            txtQuestionNo.Text = questionNo.ToString();
            lblNotSet.Visible = false;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Data Will be Lost", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                clear();
            }
        }

        private void btnFinish_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Set Will be CHanged.", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                txtSet.Text = (Int64.Parse(txtSet.Text.ToString()) + 1).ToString();
                txtQuestionNo.Text = "1";
            }
        }

        private void txtSet_TextChanged(object sender, EventArgs e)
        {
            if (txtSet.Text != "")
            {
                clear();
                Con.Open();
                string query = "SELECT nomer FROM tblQuestion where sett='"+txtSet.Text+"'";
                SqlDataAdapter sda = new SqlDataAdapter(query, Con);
                SqlCommandBuilder build = new SqlCommandBuilder(sda);
                var ds1 = new DataSet();
                sda.Fill(ds1);
                if(ds1.Tables[0].Rows.Count!=0 && ds1.Tables[0].Rows[0][0].ToString() != "")
                {
                    txtQuestionNo.Text = (ds1.Tables[0].Rows.Count + 1).ToString();
                    questionNo = Int64.Parse(txtQuestionNo.Text.ToString());
                }
                else
                {
                    txtQuestionNo.Text = "1";
                    questionNo = Int64.Parse(txtQuestionNo.Text.ToString());
                    lblNotSet.Visible = true;
                }
                Con.Close();
            }
        }
    }
}
