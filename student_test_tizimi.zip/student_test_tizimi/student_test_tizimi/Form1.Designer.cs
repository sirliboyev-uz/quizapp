﻿
namespace student_test_tizimi
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtstudentPassword = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.btnLoginStudent = new Guna.UI2.WinForms.Guna2Button();
            this.btnRegisterStudent = new Guna.UI2.WinForms.Guna2Button();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.labelWrong = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtPassTeacher = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.btnLoginTecher = new Guna.UI2.WinForms.Guna2Button();
            this.label6 = new System.Windows.Forms.Label();
            this.txtUserTeacher = new System.Windows.Forms.TextBox();
            this.panelSU = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtSUPassword = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtSUUser = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panelSU.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(212, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 29);
            this.label1.TabIndex = 1;
            this.label1.Text = "Select User:";
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Student",
            "Teacher"});
            this.comboBox1.Location = new System.Drawing.Point(58, 151);
            this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(411, 37);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(119, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(341, 37);
            this.label2.TabIndex = 3;
            this.label2.Text = "Quise / Exam System";
            // 
            // txtstudentPassword
            // 
            this.txtstudentPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtstudentPassword.Location = new System.Drawing.Point(58, 362);
            this.txtstudentPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtstudentPassword.Name = "txtstudentPassword";
            this.txtstudentPassword.Size = new System.Drawing.Size(411, 39);
            this.txtstudentPassword.TabIndex = 2;
            this.txtstudentPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label3.Location = new System.Drawing.Point(202, 340);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 20);
            this.label3.TabIndex = 5;
            this.label3.Text = "Student Keyword";
            // 
            // btnLoginStudent
            // 
            this.btnLoginStudent.BorderColor = System.Drawing.Color.Blue;
            this.btnLoginStudent.BorderRadius = 10;
            this.btnLoginStudent.BorderThickness = 3;
            this.btnLoginStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLoginStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLoginStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLoginStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLoginStudent.FillColor = System.Drawing.Color.Green;
            this.btnLoginStudent.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnLoginStudent.ForeColor = System.Drawing.Color.White;
            this.btnLoginStudent.Location = new System.Drawing.Point(160, 422);
            this.btnLoginStudent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLoginStudent.Name = "btnLoginStudent";
            this.btnLoginStudent.Size = new System.Drawing.Size(220, 49);
            this.btnLoginStudent.TabIndex = 3;
            this.btnLoginStudent.Text = "Login";
            this.btnLoginStudent.Click += new System.EventHandler(this.btnLoginStudent_Click);
            // 
            // btnRegisterStudent
            // 
            this.btnRegisterStudent.BorderColor = System.Drawing.Color.Blue;
            this.btnRegisterStudent.BorderRadius = 10;
            this.btnRegisterStudent.BorderThickness = 3;
            this.btnRegisterStudent.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnRegisterStudent.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnRegisterStudent.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnRegisterStudent.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnRegisterStudent.FillColor = System.Drawing.Color.Green;
            this.btnRegisterStudent.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnRegisterStudent.ForeColor = System.Drawing.Color.White;
            this.btnRegisterStudent.Location = new System.Drawing.Point(160, 488);
            this.btnRegisterStudent.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnRegisterStudent.Name = "btnRegisterStudent";
            this.btnRegisterStudent.Size = new System.Drawing.Size(220, 49);
            this.btnRegisterStudent.TabIndex = 4;
            this.btnRegisterStudent.Text = "Add New Student";
            this.btnRegisterStudent.Click += new System.EventHandler(this.btnRegisterStudent_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(179, 249);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 29);
            this.label4.TabIndex = 9;
            this.label4.Text = "Student Login";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.labelWrong);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.txtPassTeacher);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.btnLoginTecher);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.txtUserTeacher);
            this.panel1.Location = new System.Drawing.Point(18, 249);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(512, 470);
            this.panel1.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(54, 300);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(82, 25);
            this.label9.TabIndex = 19;
            this.label9.Text = "Sign Up";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // labelWrong
            // 
            this.labelWrong.AutoSize = true;
            this.labelWrong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelWrong.ForeColor = System.Drawing.Color.Red;
            this.labelWrong.Location = new System.Drawing.Point(117, 352);
            this.labelWrong.Name = "labelWrong";
            this.labelWrong.Size = new System.Drawing.Size(279, 25);
            this.labelWrong.TabIndex = 18;
            this.labelWrong.Text = "Wrong Username or Password";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(210, 249);
            this.checkBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(75, 24);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "Show";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label7.Location = new System.Drawing.Point(206, 181);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 20);
            this.label7.TabIndex = 16;
            this.label7.Text = "Password";
            // 
            // txtPassTeacher
            // 
            this.txtPassTeacher.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtPassTeacher.Location = new System.Drawing.Point(45, 204);
            this.txtPassTeacher.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPassTeacher.Name = "txtPassTeacher";
            this.txtPassTeacher.Size = new System.Drawing.Size(407, 39);
            this.txtPassTeacher.TabIndex = 4;
            this.txtPassTeacher.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtPassTeacher.UseSystemPasswordChar = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(166, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 29);
            this.label5.TabIndex = 14;
            this.label5.Text = "Teachers Login";
            // 
            // btnLoginTecher
            // 
            this.btnLoginTecher.BorderColor = System.Drawing.Color.Blue;
            this.btnLoginTecher.BorderRadius = 10;
            this.btnLoginTecher.BorderThickness = 3;
            this.btnLoginTecher.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLoginTecher.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLoginTecher.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLoginTecher.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLoginTecher.FillColor = System.Drawing.Color.Green;
            this.btnLoginTecher.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnLoginTecher.ForeColor = System.Drawing.Color.White;
            this.btnLoginTecher.Location = new System.Drawing.Point(147, 289);
            this.btnLoginTecher.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLoginTecher.Name = "btnLoginTecher";
            this.btnLoginTecher.Size = new System.Drawing.Size(220, 49);
            this.btnLoginTecher.TabIndex = 6;
            this.btnLoginTecher.Text = "Login";
            this.btnLoginTecher.Click += new System.EventHandler(this.btnLoginTecher_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label6.Location = new System.Drawing.Point(206, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 20);
            this.label6.TabIndex = 11;
            this.label6.Text = "Username";
            // 
            // txtUserTeacher
            // 
            this.txtUserTeacher.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtUserTeacher.Location = new System.Drawing.Point(45, 114);
            this.txtUserTeacher.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtUserTeacher.Name = "txtUserTeacher";
            this.txtUserTeacher.Size = new System.Drawing.Size(407, 39);
            this.txtUserTeacher.TabIndex = 3;
            this.txtUserTeacher.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panelSU
            // 
            this.panelSU.Controls.Add(this.label8);
            this.panelSU.Controls.Add(this.checkBox2);
            this.panelSU.Controls.Add(this.label10);
            this.panelSU.Controls.Add(this.txtSUPassword);
            this.panelSU.Controls.Add(this.label11);
            this.panelSU.Controls.Add(this.guna2Button1);
            this.panelSU.Controls.Add(this.label12);
            this.panelSU.Controls.Add(this.txtSUUser);
            this.panelSU.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSU.Location = new System.Drawing.Point(0, 0);
            this.panelSU.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panelSU.Name = "panelSU";
            this.panelSU.Size = new System.Drawing.Size(543, 732);
            this.panelSU.TabIndex = 11;
            this.panelSU.Visible = false;
            this.panelSU.Paint += new System.Windows.Forms.PaintEventHandler(this.panelSU_Paint);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(220, 538);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(112, 25);
            this.label8.TabIndex = 5;
            this.label8.Text = "Go to Login";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(231, 425);
            this.checkBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(75, 24);
            this.checkBox2.TabIndex = 3;
            this.checkBox2.Text = "Show";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label10.Location = new System.Drawing.Point(226, 358);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(83, 20);
            this.label10.TabIndex = 24;
            this.label10.Text = "Password";
            // 
            // txtSUPassword
            // 
            this.txtSUPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtSUPassword.Location = new System.Drawing.Point(65, 380);
            this.txtSUPassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSUPassword.Name = "txtSUPassword";
            this.txtSUPassword.Size = new System.Drawing.Size(411, 39);
            this.txtSUPassword.TabIndex = 2;
            this.txtSUPassword.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txtSUPassword.UseSystemPasswordChar = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(179, 172);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(207, 29);
            this.label11.TabIndex = 22;
            this.label11.Text = "Teachers Sign Up";
            // 
            // guna2Button1
            // 
            this.guna2Button1.BorderColor = System.Drawing.Color.Blue;
            this.guna2Button1.BorderRadius = 10;
            this.guna2Button1.BorderThickness = 3;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.Color.Green;
            this.guna2Button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.guna2Button1.ForeColor = System.Drawing.Color.White;
            this.guna2Button1.Location = new System.Drawing.Point(168, 465);
            this.guna2Button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(220, 49);
            this.guna2Button1.TabIndex = 4;
            this.guna2Button1.Text = "Add User";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.label12.Location = new System.Drawing.Point(226, 268);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 20);
            this.label12.TabIndex = 20;
            this.label12.Text = "Username";
            // 
            // txtSUUser
            // 
            this.txtSUUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtSUUser.Location = new System.Drawing.Point(65, 290);
            this.txtSUUser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSUUser.Name = "txtSUUser";
            this.txtSUUser.Size = new System.Drawing.Size(411, 39);
            this.txtSUUser.TabIndex = 1;
            this.txtSUUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(543, 732);
            this.Controls.Add(this.panelSU);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btnRegisterStudent);
            this.Controls.Add(this.btnLoginStudent);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtstudentPassword);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelSU.ResumeLayout(false);
            this.panelSU.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtstudentPassword;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2Button btnLoginStudent;
        private Guna.UI2.WinForms.Guna2Button btnRegisterStudent;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPassTeacher;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2Button btnLoginTecher;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtUserTeacher;
        private System.Windows.Forms.Label labelWrong;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panelSU;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSUPassword;
        private System.Windows.Forms.Label label11;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSUUser;
    }
}

