﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace student_test_tizimi
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Display();
        }

        private void Display()
        {
            Con.Open();
            string query = "SELECT * FROM UserTeacher";
            SqlDataAdapter sda = new SqlDataAdapter(query, Con);
            SqlCommandBuilder build = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            Con.Close();
        }

        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Jamol\Desktop\student_test_tizimi\student_test_tizimi\student_test_tizimi\QuiseMenegementDatabase.mdf;Integrated Security=True");
        

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (txtSUUser.Text == "" || txtSUPassword.Text == "")
            {
                MessageBox.Show("Missing Information!");
            }
            else
            {
                Con.Open();
                string query = "INSERT INTO UserTeacher (Username,password) " +
                            $"VALUES ('{txtSUUser.Text}', '{txtSUPassword.Text}')";

                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Add Succesfully!");
                Con.Close();
                Display();
                txtSUUser.Text = ""; txtSUPassword.Text = "";


            }
        }
        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                panel1.Visible = false;
                labelWrong.Visible = false;
            }
            else
            {
                panel1.Visible = true;
                labelWrong.Visible = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.Visible = false;
            comboBox1.SelectedIndex = 0;
            Display();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {
                txtPassTeacher.UseSystemPasswordChar = false;
                checkBox1.Text = "Hide";
            }
            else
            {
                txtPassTeacher.UseSystemPasswordChar = true;
                checkBox1.Text = "Show";
            }
        }

        private void label9_Click(object sender, EventArgs e)
        {
            panelSU.Visible = true;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            panelSU.Visible = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == true)
            {
                txtSUPassword.UseSystemPasswordChar = false;
                checkBox2.Text = "Hide";
            }
            else
            {
                txtSUPassword.UseSystemPasswordChar = true;
                checkBox2.Text = "Show";
            }
        }

        private void btnLoginTecher_Click(object sender, EventArgs e)
        {
            if(txtPassTeacher.Text=="Admin" && txtUserTeacher.Text == "Admin")
            {
                Teacher t = new Teacher();
                t.Show();
                this.Hide();
            }
            if (txtUserTeacher.Text != "" && txtPassTeacher.Text != "")
            {
                Con.Open();
                string query = "select count(*) from UserTeacher where Username='" + txtUserTeacher.Text + "' and " +
                    "password='" + txtPassTeacher.Text + "'";
                SqlCommand cmd = new SqlCommand(query, Con);
                int v = Convert.ToInt32(cmd.ExecuteScalar());
                if (v != 1)
                {
                    MessageBox.Show("Login yoki Password xato!", "Error!");
                }
                else
                {
                    MessageBox.Show("Kirish muvoffaqiyatli bo'ldi!");
                    Teacher home = new Teacher();
                    this.Hide();
                    home.Show();
                }
            }
        }

        private void btnLoginStudent_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Hello world");
            if (txtUserTeacher.Text != "" && txtPassTeacher.Text != "")
            {
                Con.Open();
                string query = "select * from TblStudent where studentU='" + txtstudentPassword.Text + "'";
                SqlCommand cmd = new SqlCommand(query, Con);
                int v = Convert.ToInt32(cmd.ExecuteScalar());
                MessageBox.Show("Test");
                if (v != 1)
                {
                    MessageBox.Show("There isn't this Student in Table.", "Error!");
                }
                else
                {
                    MessageBox.Show("Kirish muvoffaqiyatli bo'ldi!");
                    Student home = new Student();
                    this.Hide();
                    home.Show();
                }
            }
            if (txtstudentPassword.Text == "Odina")
            {
                MessageBox.Show("Kirish muvoffaqiyatli bo'ldi!");
                Student home = new Student();
                this.Hide();
                home.Show();
            }
        }

        private void btnRegisterStudent_Click(object sender, EventArgs e)
        {
            
            if (txtstudentPassword.Text == "")
            {
                MessageBox.Show("Missing Information!");
            }
            else
            {
                Con.Open();
                string query = "INSERT INTO TblStudent (studentU) " +
                            $"VALUES ('{txtstudentPassword.Text}')";
                SqlCommand cmd = new SqlCommand(query, Con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Add Succesfully!");
                Form1_Load(this, null);
                Con.Close();
                Display();
            }
        }

        private void panelSU_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
