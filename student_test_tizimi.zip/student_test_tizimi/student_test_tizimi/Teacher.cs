﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace student_test_tizimi
{
    public partial class Teacher : Form
    {
        public Teacher()
        {
            InitializeComponent();
        }
        UC_AddNewQuestion childForm = new UC_AddNewQuestion();
        UC_UpdateQuestion ucUp = new UC_UpdateQuestion();
        UC_ViewDeleteQuestion ucVD = new UC_ViewDeleteQuestion();
        UC_AllStudentsResult ucASR = new UC_AllStudentsResult();
        private void Teacher_Load(object sender, EventArgs e)
        {
            childForm.Visible = false;
        }

        private void btnAddNewQuestion_Click(object sender, EventArgs e)
        {
            childForm.Visible = true;

            // Guna2Elipse ni yaratish
            guna2Elipse1.TargetControl = guna2Panel1;
            guna2Elipse1.BorderRadius = 6;

            // Panelni tozalash
            guna2Panel1.Controls.Clear();

            // Target formni panelga qo'shish
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            guna2Panel1.Controls.Add(childForm);
            childForm.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnUpQuestion_Click(object sender, EventArgs e)
        {
            ucUp.Visible = true;

            // Guna2Elipse ni yaratish
            guna2Elipse1.TargetControl = guna2Panel1;
            guna2Elipse1.BorderRadius = 6;

            // Panelni tozalash
            guna2Panel1.Controls.Clear();

            // Target formni panelga qo'shish
            ucUp.TopLevel = false;
            ucUp.FormBorderStyle = FormBorderStyle.None;
            ucUp.Dock = DockStyle.Fill;
            guna2Panel1.Controls.Add(ucUp);
            ucUp.BringToFront();
        }

        private void btnVDquestion_Click(object sender, EventArgs e)
        {
            ucVD.Visible = true;

            // Guna2Elipse ni yaratish
            guna2Elipse1.TargetControl = guna2Panel1;
            guna2Elipse1.BorderRadius = 6;

            // Panelni tozalash
            guna2Panel1.Controls.Clear();

            // Target formni panelga qo'shish
            ucVD.TopLevel = false;
            ucVD.FormBorderStyle = FormBorderStyle.None;
            ucVD.Dock = DockStyle.Fill;
            guna2Panel1.Controls.Add(ucVD);
            ucVD.BringToFront();
        }

        private void guna2Button5_Click(object sender, EventArgs e)
        {
            Form1 fr1 = new Form1();
            this.Hide();
            fr1.Show();
        }

        private void guna2Button4_Click(object sender, EventArgs e)
        {
            ucASR.Visible = true;

            // Guna2Elipse ni yaratish
            guna2Elipse1.TargetControl = guna2Panel1;
            guna2Elipse1.BorderRadius = 6;

            // Panelni tozalash
            guna2Panel1.Controls.Clear();

            // Target formni panelga qo'shish
            ucASR.TopLevel = false;
            ucASR.FormBorderStyle = FormBorderStyle.None;
            ucASR.Dock = DockStyle.Fill;
            guna2Panel1.Controls.Add(ucASR);
            ucASR.Show();
        }
    }
}
